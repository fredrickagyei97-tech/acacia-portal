import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../lib/auth.jsx'
import { supabase } from '../lib/supabase.js'

export default function LoginPage() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const [role, setRole] = useState(null)
  const [agentId, setAgentId] = useState('')
  const [pin, setPin] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const agents = [
    { id: 'ACA-001', name: 'Kwame Asante' }, { id: 'ACA-002', name: 'Abena Mensah' },
    { id: 'ACA-003', name: 'Kojo Boateng' }, { id: 'ACA-004', name: 'Ama Owusu' },
    { id: 'ACA-005', name: 'Fiifi Darko' }, { id: 'ACA-006', name: 'Efua Annan' },
    { id: 'ACA-007', name: 'Yaw Acheampong' }, { id: 'ACA-008', name: 'Akosua Frimpong' },
    { id: 'ACA-009', name: 'Nana Boakye' }, { id: 'ACA-010', name: 'Adwoa Tetteh' }
  ]

  const handleLogin = async () => {
    setError(''); setLoading(true)
    try {
      if (role === 'head') {
        const { data } = await supabase.from('unit_head').select('pin,name').eq('id', 1).single()
        if (!data || data.pin !== pin) { setError('Incorrect PIN'); setLoading(false); return }
        login({ role: 'head', name: data.name })
        navigate('/dashboard')
      } else {
        if (!agentId) { setError('Please select your name'); setLoading(false); return }
        const { data } = await supabase.from('agents').select('*').eq('id', agentId).single()
        if (!data || data.pin !== pin) { setError('Incorrect PIN'); setLoading(false); return }
        login({ role: 'agent', agentId: data.id, name: data.name, zone: data.zone })
        navigate('/agent')
      }
    } catch (e) {
      setError('Connection error. Check Supabase config.')
    }
    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0d3349] via-[#1A5276] to-[#0d3349] flex items-center justify-center p-4">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5" style={{backgroundImage:'radial-gradient(circle at 25px 25px, white 2px, transparent 0)',backgroundSize:'50px 50px'}}/>

      <div className="relative w-full max-w-md">
        {/* Logo / Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white/10 backdrop-blur mb-4">
            <span className="text-3xl">🏥</span>
          </div>
          <h1 className="font-display text-2xl text-white font-bold tracking-tight">Acacia Health Insurance</h1>
          <p className="text-white/60 text-sm mt-1">Retail Unit · Agent Management Portal</p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          {/* Role selector */}
          <div className="grid grid-cols-2 border-b border-slate-100">
            {[['head','Unit Head','🏢','Full management access'],['agent','Health Planner','👤','Log & view your activities']].map(([r,label,icon,sub])=>(
              <button key={r} onClick={()=>{setRole(r);setError('');setPin('');setAgentId('')}}
                className={`p-5 text-left transition-all duration-200 ${role===r?'bg-[#1A5276]/5 border-b-2 border-[#1A5276]':'hover:bg-slate-50 border-b-2 border-transparent'}`}>
                <div className="text-xl mb-1">{icon}</div>
                <div className={`text-sm font-semibold ${role===r?'text-[#1A5276]':'text-slate-700'}`}>{label}</div>
                <div className="text-xs text-slate-400 mt-0.5">{sub}</div>
              </button>
            ))}
          </div>

          {/* Form */}
          <div className="p-6">
            {!role && (
              <p className="text-center text-slate-400 text-sm py-4">Select a login type above to continue</p>
            )}
            {role === 'agent' && (
              <div className="mb-4">
                <label className="block text-xs font-medium text-slate-500 mb-1.5">Select your name</label>
                <select value={agentId} onChange={e=>setAgentId(e.target.value)} className="form-input">
                  <option value="">-- Choose Health Planner --</option>
                  {agents.map(a=><option key={a.id} value={a.id}>{a.name} ({a.id})</option>)}
                </select>
              </div>
            )}
            {role && (
              <>
                <div className="mb-4">
                  <label className="block text-xs font-medium text-slate-500 mb-1.5">PIN</label>
                  <input type="password" value={pin} onChange={e=>setPin(e.target.value)}
                    onKeyDown={e=>e.key==='Enter'&&handleLogin()}
                    placeholder="Enter your PIN" maxLength={6} className="form-input"/>
                </div>
                {error && <p className="text-red-500 text-xs mb-3">{error}</p>}
                <button onClick={handleLogin} disabled={loading} className="btn-primary w-full justify-center flex items-center gap-2">
                  {loading ? <span className="animate-pulse">Signing in...</span> : `Sign In as ${role==='head'?'Unit Head':'Health Planner'}`}
                </button>
              </>
            )}
          </div>
        </div>
        <p className="text-center text-white/30 text-xs mt-6">Acacia Health Insurance Ltd · Retail Unit Portal v1.0</p>
      </div>
    </div>
  )
}
