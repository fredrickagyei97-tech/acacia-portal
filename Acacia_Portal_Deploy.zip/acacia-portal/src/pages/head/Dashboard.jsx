import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../../lib/supabase.js'
import { PageShell, StatCard, Avatar, ScoreBadge, StatusBadge, OutcomeBadge, ProgressBar } from '../../components/shared.jsx'

function calcScore(kpi) {
  if (!kpi) return 0
  const np = kpi.new_clients_target > 0 ? (kpi.new_clients_actual||0) / kpi.new_clients_target : 0
  const rp = kpi.renewals_target > 0 ? (kpi.renewals_actual||0) / kpi.renewals_target : 0
  const pp = kpi.premium_target > 0 ? (kpi.premium_actual||0) / kpi.premium_target : 0
  return Math.round((np*0.4 + rp*0.3 + pp*0.3) * 100)
}

export default function Dashboard() {
  const [agents, setAgents] = useState([])
  const [kpis, setKpis] = useState({})
  const [activities, setActivities] = useState([])
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()
  const now = new Date(); const month = now.toLocaleString('default',{month:'long'}); const year = now.getFullYear()

  useEffect(() => {
    async function load() {
      const [{ data: ag }, { data: kp }, { data: ac }] = await Promise.all([
        supabase.from('agents').select('*').order('id'),
        supabase.from('kpi_targets').select('*').eq('month', month).eq('year', year),
        supabase.from('activities').select('*').order('logged_at', { ascending: false }).limit(8)
      ])
      setAgents(ag || [])
      const kpMap = {}; (kp||[]).forEach(k => kpMap[k.agent_id] = k); setKpis(kpMap)
      setActivities(ac || [])
      setLoading(false)
    }
    load()
  }, [])

  if (loading) return <main className="ml-52 mt-14 p-6 flex items-center justify-center h-64"><div className="text-slate-400 animate-pulse">Loading dashboard...</div></main>

  const active = agents.filter(a => a.status === 'Active').length
  const totalPolicies = Object.values(kpis).reduce((s,k)=>s+(k.new_clients_actual||0),0)
  const totalPremium = Object.values(kpis).reduce((s,k)=>s+(k.premium_actual||0),0)
  const stars = agents.filter(a => calcScore(kpis[a.id]) >= 90).length

  return (
    <PageShell title="Dashboard" subtitle={`${month} ${year} — Retail Unit overview`}>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total Agents" value="10" color="text-[#1A5276]"/>
        <StatCard label="Active Agents" value={active} color="text-[#1E8449]"/>
        <StatCard label={`${month} Policies`} value={totalPolicies} color="text-blue-700"/>
        <StatCard label={`${month} Premium`} value={`GHS ${totalPremium.toLocaleString()}`} color="text-amber-700" sub="collected"/>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Agent snapshot */}
        <div className="card overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
            <span className="font-display font-bold text-slate-700 text-sm">Agent Performance</span>
            <button onClick={()=>navigate('/dashboard/kpi')} className="text-xs text-[#1A5276] hover:underline">View KPIs →</button>
          </div>
          <div className="divide-y divide-slate-50">
            {agents.map(a => {
              const sc = calcScore(kpis[a.id])
              const k = kpis[a.id] || {}
              return (
                <div key={a.id} onClick={()=>navigate(`/dashboard/agents/${a.id}`)}
                  className="flex items-center gap-3 px-4 py-3 hover:bg-slate-50 cursor-pointer transition-colors">
                  <Avatar name={a.name} id={a.id}/>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-slate-800 truncate">{a.name}</div>
                    <ProgressBar value={k.new_clients_actual||0} max={k.new_clients_target||20}/>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <div className="text-sm font-bold" style={{color: sc>=75?'#1E8449':sc>=60?'#854F0B':'#E74C3C'}}>{sc}%</div>
                    <ScoreBadge score={sc}/>
                  </div>
                  <StatusBadge status={a.status}/>
                </div>
              )
            })}
          </div>
        </div>

        <div className="flex flex-col gap-4">
          {/* Recent activities */}
          <div className="card overflow-hidden flex-1">
            <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
              <span className="font-display font-bold text-slate-700 text-sm">Recent Activities</span>
              <button onClick={()=>navigate('/dashboard/activities')} className="text-xs text-[#1A5276] hover:underline">View all →</button>
            </div>
            {activities.length === 0
              ? <div className="p-4 text-sm text-slate-400 text-center">No activities logged yet</div>
              : <div className="divide-y divide-slate-50">
                  {activities.map(a => (
                    <div key={a.id} className="px-4 py-3 flex items-start gap-3">
                      <Avatar name={a.agent_name} id={a.agent_id} size="sm"/>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-medium text-slate-700">{a.agent_name} · <span className="text-slate-500">{a.activity_type}</span></div>
                        <div className="text-xs text-slate-400 truncate">{a.client_name}</div>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <OutcomeBadge outcome={a.outcome}/>
                        <div className="text-[10px] text-slate-400 mt-0.5">{a.date}</div>
                      </div>
                    </div>
                  ))}
                </div>}
          </div>

          {/* Quick stats */}
          <div className="grid grid-cols-2 gap-3">
            <StatCard label="Star Performers" value={stars} color="text-[#1E8449]" sub="score ≥ 90%"/>
            <StatCard label="Activities Logged" value={activities.length} color="text-blue-700" sub="this session"/>
          </div>
        </div>
      </div>
    </PageShell>
  )
}
