import { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase.js'
import { PageShell, OutcomeBadge, Avatar } from '../../components/shared.jsx'

export default function AllActivities() {
  const [activities, setActivities] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState({ agent: '', type: '', outcome: '' })

  useEffect(() => {
    supabase.from('activities').select('*').order('date', { ascending: false }).then(({ data }) => {
      setActivities(data||[])
      setLoading(false)
    })
  }, [])

  const filtered = activities.filter(a =>
    (!filter.agent || a.agent_id === filter.agent) &&
    (!filter.type || a.activity_type === filter.type) &&
    (!filter.outcome || a.outcome === filter.outcome)
  )

  const agents = [...new Set(activities.map(a=>a.agent_id))].map(id=>({ id, name: activities.find(a=>a.agent_id===id)?.agent_name }))
  const types = [...new Set(activities.map(a=>a.activity_type))]
  const outcomes = [...new Set(activities.map(a=>a.outcome))]

  if (loading) return <main className="ml-52 mt-14 p-6"><div className="text-slate-400 animate-pulse">Loading...</div></main>

  return (
    <PageShell title="All Activities" subtitle={`${filtered.length} records across all agents`}>
      {/* Filters */}
      <div className="flex gap-3 mb-4 flex-wrap">
        <select value={filter.agent} onChange={e=>setFilter(f=>({...f,agent:e.target.value}))} className="form-input w-auto">
          <option value="">All Agents</option>
          {agents.map(a=><option key={a.id} value={a.id}>{a.name}</option>)}
        </select>
        <select value={filter.type} onChange={e=>setFilter(f=>({...f,type:e.target.value}))} className="form-input w-auto">
          <option value="">All Activity Types</option>
          {types.map(t=><option key={t}>{t}</option>)}
        </select>
        <select value={filter.outcome} onChange={e=>setFilter(f=>({...f,outcome:e.target.value}))} className="form-input w-auto">
          <option value="">All Outcomes</option>
          {outcomes.map(o=><option key={o}>{o}</option>)}
        </select>
        {(filter.agent||filter.type||filter.outcome) && (
          <button onClick={()=>setFilter({agent:'',type:'',outcome:''})} className="btn-secondary text-xs">Clear filters</button>
        )}
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-100">
              {['Date','Agent','Activity Type','Client','Contact','Plan','Premium','Follow-Up','Outcome','Notes'].map(h=>(
                <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-slate-400 uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0
              ? <tr><td colSpan={10} className="px-4 py-10 text-center text-slate-400">No activities found</td></tr>
              : filtered.map(a => (
                <tr key={a.id} className="table-row">
                  <td className="px-4 py-3 text-xs text-slate-500 whitespace-nowrap">{a.date}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Avatar name={a.agent_name} id={a.agent_id} size="sm"/>
                      <span className="font-medium text-slate-700 whitespace-nowrap">{a.agent_name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-slate-700 whitespace-nowrap">{a.activity_type}</td>
                  <td className="px-4 py-3 text-slate-600">{a.client_name}</td>
                  <td className="px-4 py-3 text-xs text-slate-500">{a.contact_mode}</td>
                  <td className="px-4 py-3 text-xs text-slate-500">{a.plan||'—'}</td>
                  <td className="px-4 py-3 text-xs font-medium text-[#1E8449]">{a.premium>0?`GHS ${a.premium.toLocaleString()}`:'—'}</td>
                  <td className="px-4 py-3 text-xs text-blue-600">{a.follow_up_date||'—'}</td>
                  <td className="px-4 py-3"><OutcomeBadge outcome={a.outcome}/></td>
                  <td className="px-4 py-3 text-xs text-slate-400 max-w-xs truncate">{a.notes||'—'}</td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </PageShell>
  )
}
