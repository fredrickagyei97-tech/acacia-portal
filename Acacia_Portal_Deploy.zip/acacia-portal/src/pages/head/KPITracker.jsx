import { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase.js'
import { PageShell, ScoreBadge, ProgressBar, Toast } from '../../components/shared.jsx'

function calcScore(k) {
  if (!k) return 0
  const np = k.new_clients_target > 0 ? (k.new_clients_actual||0)/k.new_clients_target : 0
  const rp = k.renewals_target > 0 ? (k.renewals_actual||0)/k.renewals_target : 0
  const pp = k.premium_target > 0 ? (k.premium_actual||0)/k.premium_target : 0
  return Math.round((np*0.4+rp*0.3+pp*0.3)*100)
}

export default function KPITracker() {
  const [agents, setAgents] = useState([])
  const [kpis, setKpis] = useState({})
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(null)
  const [editVals, setEditVals] = useState({})
  const [toast, setToast] = useState(null)
  const now = new Date(); const month = now.toLocaleString('default',{month:'long'}); const year = now.getFullYear()

  useEffect(() => {
    async function load() {
      const [{ data: ag }, { data: kp }] = await Promise.all([
        supabase.from('agents').select('*').order('id'),
        supabase.from('kpi_targets').select('*').eq('month', month).eq('year', year)
      ])
      setAgents(ag||[])
      const m = {}; (kp||[]).forEach(k=>m[k.agent_id]=k); setKpis(m)
      setLoading(false)
    }
    load()
  }, [])

  const saveKpi = async (agentId) => {
    const { error } = await supabase.from('kpi_targets').upsert({
      agent_id: agentId, month, year, ...editVals
    }, { onConflict: 'agent_id,month,year' })
    if (!error) {
      setKpis(k=>({...k,[agentId]:{...k[agentId],...editVals,agent_id:agentId,month,year}}))
      setEditing(null); setToast('KPI updated'); setTimeout(()=>setToast(null),2500)
    }
  }

  if (loading) return <main className="ml-52 mt-14 p-6"><div className="text-slate-400 animate-pulse">Loading...</div></main>

  return (
    <PageShell title="KPI Tracker" subtitle={`${month} ${year} — Targets vs Actuals`}>
      {toast && <Toast msg={toast}/>}
      <div className="card overflow-x-auto">
        <table className="w-full text-sm min-w-[900px]">
          <thead>
            <tr className="border-b border-slate-100">
              <th className="text-left px-4 py-3 text-xs text-slate-400 uppercase tracking-wide font-semibold">Agent</th>
              <th className="text-center px-3 py-3 text-xs text-slate-400 uppercase tracking-wide font-semibold" colSpan={2}>New Clients</th>
              <th className="text-center px-3 py-3 text-xs text-slate-400 uppercase tracking-wide font-semibold" colSpan={2}>Renewals</th>
              <th className="text-center px-3 py-3 text-xs text-slate-400 uppercase tracking-wide font-semibold" colSpan={2}>Premium (GHS)</th>
              <th className="text-center px-3 py-3 text-xs text-slate-400 uppercase tracking-wide font-semibold">Score</th>
              <th className="px-3 py-3"></th>
            </tr>
            <tr className="border-b border-slate-50">
              <th></th>
              {['Target','Actual','Target','Actual','Target','Actual'].map((h,i)=>(
                <th key={i} className="text-center px-3 py-1.5 text-[11px] text-slate-300 font-medium">{h}</th>
              ))}
              <th></th><th></th>
            </tr>
          </thead>
          <tbody>
            {agents.map(a => {
              const k = kpis[a.id] || {}
              const sc = calcScore(k)
              const isEditing = editing === a.id
              return (
                <tr key={a.id} className="table-row">
                  <td className="px-4 py-3 font-medium text-slate-800">{a.name}</td>
                  {isEditing ? (
                    <>
                      {[['new_clients_target','new_clients_actual'],['renewals_target','renewals_actual'],['premium_target','premium_actual']].map(([t,ac])=>(
                        <>
                          <td key={t} className="px-2 py-2"><input type="number" value={editVals[t]||0} onChange={e=>setEditVals(v=>({...v,[t]:parseFloat(e.target.value)||0}))} className="form-input text-xs text-center py-1"/></td>
                          <td key={ac} className="px-2 py-2"><input type="number" value={editVals[ac]||0} onChange={e=>setEditVals(v=>({...v,[ac]:parseFloat(e.target.value)||0}))} className="form-input text-xs text-center py-1 border-[#1E8449]/40"/></td>
                        </>
                      ))}
                    </>
                  ) : (
                    <>
                      <td className="px-3 py-3 text-center text-slate-500">{k.new_clients_target||'—'}</td>
                      <td className="px-3 py-3 text-center font-medium">{k.new_clients_actual||0}</td>
                      <td className="px-3 py-3 text-center text-slate-500">{k.renewals_target||'—'}</td>
                      <td className="px-3 py-3 text-center font-medium">{k.renewals_actual||0}</td>
                      <td className="px-3 py-3 text-center text-slate-500">{k.premium_target?.toLocaleString()||'—'}</td>
                      <td className="px-3 py-3 text-center font-medium">{(k.premium_actual||0).toLocaleString()}</td>
                    </>
                  )}
                  <td className="px-3 py-3 text-center">
                    <div className="flex flex-col items-center gap-1">
                      <span className="font-bold text-sm" style={{color:sc>=75?'#1E8449':sc>=60?'#854F0B':'#E74C3C'}}>{sc}%</span>
                      <ScoreBadge score={sc}/>
                    </div>
                  </td>
                  <td className="px-3 py-3">
                    {isEditing ? (
                      <div className="flex gap-1">
                        <button onClick={()=>saveKpi(a.id)} className="btn-success text-xs py-1 px-2">Save</button>
                        <button onClick={()=>setEditing(null)} className="btn-secondary text-xs py-1 px-2">×</button>
                      </div>
                    ) : (
                      <button onClick={()=>{setEditing(a.id);setEditVals({
                        new_clients_target:k.new_clients_target||20,new_clients_actual:k.new_clients_actual||0,
                        renewals_target:k.renewals_target||8,renewals_actual:k.renewals_actual||0,
                        premium_target:k.premium_target||15000,premium_actual:k.premium_actual||0
                      })}} className="btn-secondary text-xs py-1 px-2.5">Edit</button>
                    )}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-slate-400 mt-3">Scoring: New Clients 40% + Renewals 30% + Premium 30% | STAR ≥ 90% · HIGH ≥ 75% · MID ≥ 60% · LOW &lt; 60%</p>
    </PageShell>
  )
}
