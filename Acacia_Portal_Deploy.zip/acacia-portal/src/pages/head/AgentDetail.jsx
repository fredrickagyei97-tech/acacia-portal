import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { supabase } from '../../lib/supabase.js'
import { PageShell, Avatar, StatusBadge, OutcomeBadge, ProgressBar, ScoreBadge, Modal, FormGroup, Toast } from '../../components/shared.jsx'

function calcScore(k) {
  if (!k) return 0
  const np = k.new_clients_target > 0 ? (k.new_clients_actual||0)/k.new_clients_target : 0
  const rp = k.renewals_target > 0 ? (k.renewals_actual||0)/k.renewals_target : 0
  const pp = k.premium_target > 0 ? (k.premium_actual||0)/k.premium_target : 0
  return Math.round((np*0.4+rp*0.3+pp*0.3)*100)
}

export default function AgentDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [agent, setAgent] = useState(null)
  const [kpi, setKpi] = useState(null)
  const [activities, setActivities] = useState([])
  const [loading, setLoading] = useState(true)
  const [editKpi, setEditKpi] = useState(false)
  const [kpiForm, setKpiForm] = useState({})
  const [toast, setToast] = useState(null)
  const now = new Date(); const month = now.toLocaleString('default',{month:'long'}); const year = now.getFullYear()

  useEffect(() => {
    async function load() {
      const [{ data: ag }, { data: kp }, { data: ac }] = await Promise.all([
        supabase.from('agents').select('*').eq('id', id).single(),
        supabase.from('kpi_targets').select('*').eq('agent_id', id).eq('month', month).eq('year', year).single(),
        supabase.from('activities').select('*').eq('agent_id', id).order('date', { ascending: false })
      ])
      setAgent(ag); setKpi(kp); setActivities(ac||[]); setLoading(false)
    }
    load()
  }, [id])

  const saveKpi = async () => {
    const { error } = await supabase.from('kpi_targets').upsert({
      agent_id: id, month, year, ...kpiForm
    }, { onConflict: 'agent_id,month,year' })
    if (!error) {
      setKpi(k => ({...k,...kpiForm})); setEditKpi(false)
      setToast('KPI targets updated'); setTimeout(()=>setToast(null), 2500)
    }
  }

  if (loading) return <main className="ml-52 mt-14 p-6"><div className="text-slate-400 animate-pulse">Loading agent...</div></main>
  if (!agent) return <main className="ml-52 mt-14 p-6"><div className="text-red-500">Agent not found</div></main>

  const sc = calcScore(kpi)

  return (
    <PageShell
      title={agent.name}
      subtitle={`${agent.id} · ${agent.zone}`}
      action={<button onClick={()=>navigate('/dashboard/agents')} className="btn-secondary">← Back to Roster</button>}
    >
      {toast && <Toast msg={toast}/>}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left col */}
        <div className="space-y-4">
          <div className="card p-5">
            <div className="flex items-center gap-3 mb-4">
              <Avatar name={agent.name} id={agent.id} size="lg"/>
              <div>
                <div className="font-display font-bold text-slate-800">{agent.name}</div>
                <div className="text-xs text-slate-400">{agent.id}</div>
                <StatusBadge status={agent.status}/>
              </div>
            </div>
            <div className="space-y-2 text-sm">
              {[['Zone', agent.zone],['Contract', agent.contract_type],['Phone', agent.phone],['Email', agent.email],['Joined', agent.joined],['License', agent.license_no],['License Expiry', agent.license_expiry]].map(([k,v])=>(
                <div key={k} className="flex justify-between gap-2">
                  <span className="text-slate-400 text-xs">{k}</span>
                  <span className="text-slate-700 text-xs text-right">{v}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="card p-5">
            <div className="flex items-center justify-between mb-4">
              <span className="font-display font-bold text-slate-700 text-sm">KPIs — {month} {year}</span>
              <button onClick={()=>{setKpiForm({
                new_clients_target:kpi?.new_clients_target||20,
                new_clients_actual:kpi?.new_clients_actual||0,
                renewals_target:kpi?.renewals_target||8,
                renewals_actual:kpi?.renewals_actual||0,
                premium_target:kpi?.premium_target||15000,
                premium_actual:kpi?.premium_actual||0
              });setEditKpi(true)}} className="text-xs text-[#1A5276] hover:underline">Edit</button>
            </div>
            {kpi ? <>
              {[
                {label:'New Clients',actual:kpi.new_clients_actual||0,target:kpi.new_clients_target},
                {label:'Renewals',actual:kpi.renewals_actual||0,target:kpi.renewals_target},
                {label:'Premium (GHS)',actual:kpi.premium_actual||0,target:kpi.premium_target,format:true}
              ].map(k=>(
                <div key={k.label} className="mb-3">
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-500">{k.label}</span>
                    <span className="text-slate-700">{k.format?`${k.actual.toLocaleString()} / ${k.target.toLocaleString()}`:`${k.actual} / ${k.target}`}</span>
                  </div>
                  <ProgressBar value={k.actual} max={k.target}/>
                </div>
              ))}
              <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs text-slate-500">Overall Score</span>
                <div className="flex items-center gap-2"><span className="font-bold text-lg" style={{color:sc>=75?'#1E8449':sc>=60?'#854F0B':'#E74C3C'}}>{sc}%</span><ScoreBadge score={sc}/></div>
              </div>
            </> : <div className="text-xs text-slate-400">No KPI targets set for this month</div>}
          </div>
        </div>

        {/* Activity log */}
        <div className="lg:col-span-2 card overflow-hidden">
          <div className="px-5 py-3 border-b border-slate-100">
            <span className="font-display font-bold text-slate-700 text-sm">Activity Log ({activities.length})</span>
          </div>
          {activities.length === 0
            ? <div className="p-8 text-center text-slate-400 text-sm">No activities logged yet for this agent</div>
            : <div className="divide-y divide-slate-50">
                {activities.map(a => (
                  <div key={a.id} className="px-5 py-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-medium text-slate-800">{a.activity_type}</span>
                          <span className="text-slate-400 text-xs">·</span>
                          <span className="text-sm text-slate-600">{a.client_name}</span>
                          <span className="text-xs text-slate-400">{a.contact_mode}</span>
                        </div>
                        {a.plan && <div className="text-xs text-slate-400 mt-0.5">{a.plan}</div>}
                        {a.premium > 0 && <div className="text-xs text-[#1E8449] font-medium mt-0.5">GHS {a.premium.toLocaleString()}</div>}
                        {a.notes && <div className="text-xs text-slate-500 mt-1 italic">{a.notes}</div>}
                        {a.follow_up_date && <div className="text-xs text-blue-600 mt-0.5">Follow-up: {a.follow_up_date}</div>}
                      </div>
                      <div className="text-right flex-shrink-0">
                        <OutcomeBadge outcome={a.outcome}/>
                        <div className="text-[10px] text-slate-400 mt-1">{a.date}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>}
        </div>
      </div>

      {editKpi && (
        <Modal title={`Edit KPI Targets — ${agent.name}`} onClose={()=>setEditKpi(false)}>
          <div className="grid grid-cols-2 gap-4">
            {[
              ['new_clients_target','New Clients Target'],['new_clients_actual','New Clients Actual'],
              ['renewals_target','Renewals Target'],['renewals_actual','Renewals Actual'],
              ['premium_target','Premium Target (GHS)'],['premium_actual','Premium Actual (GHS)']
            ].map(([key,label])=>(
              <FormGroup key={key} label={label}>
                <input type="number" value={kpiForm[key]||0} onChange={e=>setKpiForm(f=>({...f,[key]:parseFloat(e.target.value)||0}))} className="form-input"/>
              </FormGroup>
            ))}
          </div>
          <div className="flex gap-3 justify-end mt-4">
            <button onClick={()=>setEditKpi(false)} className="btn-secondary">Cancel</button>
            <button onClick={saveKpi} className="btn-success">Save KPIs</button>
          </div>
        </Modal>
      )}
    </PageShell>
  )
}
