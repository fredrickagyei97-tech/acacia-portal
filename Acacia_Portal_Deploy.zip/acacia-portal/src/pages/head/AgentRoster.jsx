import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../../lib/supabase.js'
import { PageShell, Avatar, StatusBadge } from '../../components/shared.jsx'

export default function AgentRoster() {
  const [agents, setAgents] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const navigate = useNavigate()

  useEffect(() => {
    supabase.from('agents').select('*').order('id').then(({ data }) => {
      setAgents(data || [])
      setLoading(false)
    })
  }, [])

  const filtered = agents.filter(a =>
    a.name.toLowerCase().includes(search.toLowerCase()) ||
    a.zone?.toLowerCase().includes(search.toLowerCase()) ||
    a.id.toLowerCase().includes(search.toLowerCase())
  )

  if (loading) return <main className="ml-52 mt-14 p-6"><div className="text-slate-400 animate-pulse">Loading...</div></main>

  return (
    <PageShell title="Agent Roster" subtitle={`${agents.length} Health Planners registered`}>
      <div className="mb-4">
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search by name, zone, or ID..."
          className="form-input max-w-sm"/>
      </div>
      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-100">
              {['Agent','ID','Zone / Territory','Contract','Phone','Email','License Expiry','Status',''].map(h=>(
                <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-slate-400 uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map(a => (
              <tr key={a.id} className="table-row cursor-pointer" onClick={()=>navigate(`/dashboard/agents/${a.id}`)}>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2.5">
                    <Avatar name={a.name} id={a.id}/>
                    <span className="font-medium text-slate-800">{a.name}</span>
                  </div>
                </td>
                <td className="px-4 py-3 text-slate-400 text-xs font-mono">{a.id}</td>
                <td className="px-4 py-3 text-slate-600">{a.zone}</td>
                <td className="px-4 py-3">
                  <span className={`badge ${a.contract_type==='Full-Time'?'badge-blue':'badge-gray'}`}>{a.contract_type}</span>
                </td>
                <td className="px-4 py-3 text-slate-500">{a.phone}</td>
                <td className="px-4 py-3 text-slate-500 text-xs">{a.email}</td>
                <td className="px-4 py-3 text-slate-500 text-xs">{a.license_expiry}</td>
                <td className="px-4 py-3"><StatusBadge status={a.status}/></td>
                <td className="px-4 py-3">
                  <button className="btn-secondary text-xs py-1 px-2.5">View →</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </PageShell>
  )
}
