import { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase.js'
import { PageShell, Modal, FormGroup, Toast, Avatar } from '../../components/shared.jsx'

const AGENTS = ['ACA-001','ACA-002','ACA-003','ACA-004','ACA-005','ACA-006','ACA-007','ACA-008','ACA-009','ACA-010']
const AGENT_NAMES = {'ACA-001':'Kwame Asante','ACA-002':'Abena Mensah','ACA-003':'Kojo Boateng','ACA-004':'Ama Owusu','ACA-005':'Fiifi Darko','ACA-006':'Efua Annan','ACA-007':'Yaw Acheampong','ACA-008':'Akosua Frimpong','ACA-009':'Nana Boakye','ACA-010':'Adwoa Tetteh'}

const TYPES = ['Weekly 1-on-1','Monthly Review','Quarterly Appraisal','Performance Improvement','Product Training','Goal Setting','Motivational','Disciplinary']

const defaultForm = { agent_id:'', date: new Date().toISOString().slice(0,10), meeting_type:'Weekly 1-on-1', discussion_points:'', targets_set:'', challenges:'', action_items:'', follow_up_date:'' }

export default function CoachingLog() {
  const [sessions, setSessions] = useState([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState(defaultForm)
  const [saving, setSaving] = useState(false)
  const [toast, setToast] = useState(null)

  useEffect(() => {
    supabase.from('coaching_log').select('*').order('date', { ascending: false }).then(({ data }) => {
      setSessions(data||[]); setLoading(false)
    })
  }, [])

  const save = async () => {
    if (!form.agent_id || !form.date) { alert('Select agent and date'); return }
    setSaving(true)
    const { data, error } = await supabase.from('coaching_log').insert([form]).select().single()
    if (!error) {
      setSessions(s=>[data,...s]); setShowModal(false); setForm(defaultForm)
      setToast('Coaching session saved'); setTimeout(()=>setToast(null),2500)
    }
    setSaving(false)
  }

  if (loading) return <main className="ml-52 mt-14 p-6"><div className="text-slate-400 animate-pulse">Loading...</div></main>

  return (
    <PageShell title="Coaching Log" subtitle="Record all meetings and coaching sessions with agents"
      action={<button onClick={()=>setShowModal(true)} className="btn-success">+ New Session</button>}>
      {toast && <Toast msg={toast}/>}

      {sessions.length === 0
        ? <div className="card p-12 text-center text-slate-400">No coaching sessions logged yet. Click "New Session" to add one.</div>
        : <div className="space-y-3">
            {sessions.map(s=>(
              <div key={s.id} className="card p-4">
                <div className="flex items-start gap-3">
                  <Avatar name={AGENT_NAMES[s.agent_id]||s.agent_id} id={s.agent_id}/>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium text-slate-800">{AGENT_NAMES[s.agent_id]||s.agent_id}</span>
                      <span className="badge badge-blue">{s.meeting_type}</span>
                      <span className="text-xs text-slate-400">{s.date}</span>
                      {s.follow_up_date && <span className="text-xs text-blue-600">Follow-up: {s.follow_up_date}</span>}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-3 text-xs">
                      {s.discussion_points && <div><div className="font-medium text-slate-500 mb-1">Discussion</div><div className="text-slate-600">{s.discussion_points}</div></div>}
                      {s.action_items && <div><div className="font-medium text-slate-500 mb-1">Action Items</div><div className="text-slate-600">{s.action_items}</div></div>}
                      {s.challenges && <div><div className="font-medium text-slate-500 mb-1">Challenges</div><div className="text-slate-600">{s.challenges}</div></div>}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>}

      {showModal && (
        <Modal title="New Coaching Session" onClose={()=>setShowModal(false)}>
          <div className="grid grid-cols-2 gap-3">
            <FormGroup label="Agent *">
              <select value={form.agent_id} onChange={e=>setForm(f=>({...f,agent_id:e.target.value}))} className="form-input">
                <option value="">-- Select Agent --</option>
                {AGENTS.map(id=><option key={id} value={id}>{AGENT_NAMES[id]}</option>)}
              </select>
            </FormGroup>
            <FormGroup label="Date *">
              <input type="date" value={form.date} onChange={e=>setForm(f=>({...f,date:e.target.value}))} className="form-input"/>
            </FormGroup>
            <FormGroup label="Meeting Type">
              <select value={form.meeting_type} onChange={e=>setForm(f=>({...f,meeting_type:e.target.value}))} className="form-input">
                {TYPES.map(t=><option key={t}>{t}</option>)}
              </select>
            </FormGroup>
            <FormGroup label="Follow-Up Date">
              <input type="date" value={form.follow_up_date} onChange={e=>setForm(f=>({...f,follow_up_date:e.target.value}))} className="form-input"/>
            </FormGroup>
          </div>
          <FormGroup label="Discussion Points">
            <textarea value={form.discussion_points} onChange={e=>setForm(f=>({...f,discussion_points:e.target.value}))} className="form-input" rows={2}/>
          </FormGroup>
          <FormGroup label="Targets Set">
            <textarea value={form.targets_set} onChange={e=>setForm(f=>({...f,targets_set:e.target.value}))} className="form-input" rows={2}/>
          </FormGroup>
          <FormGroup label="Action Items">
            <textarea value={form.action_items} onChange={e=>setForm(f=>({...f,action_items:e.target.value}))} className="form-input" rows={2}/>
          </FormGroup>
          <FormGroup label="Challenges Raised">
            <textarea value={form.challenges} onChange={e=>setForm(f=>({...f,challenges:e.target.value}))} className="form-input" rows={2}/>
          </FormGroup>
          <div className="flex gap-3 justify-end mt-2">
            <button onClick={()=>setShowModal(false)} className="btn-secondary">Cancel</button>
            <button onClick={save} disabled={saving} className="btn-success">{saving?'Saving...':'Save Session'}</button>
          </div>
        </Modal>
      )}
    </PageShell>
  )
}
