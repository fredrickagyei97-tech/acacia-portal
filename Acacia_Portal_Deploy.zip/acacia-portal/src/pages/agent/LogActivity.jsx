import { useState, useEffect } from 'react'
import { useAuth } from '../../lib/auth.jsx'
import { supabase } from '../../lib/supabase.js'
import { PageShell, StatCard, OutcomeBadge, Toast, FormGroup } from '../../components/shared.jsx'

const ACTIVITY_TYPES = ['Prospecting Call','Client Visit','Policy Renewal','Claims Support','New Policy Sold','Product Presentation','Follow-Up Call','Group Enrollment']
const OUTCOMES = ['Successful','Follow-Up Needed','Not Interested','Closed','Pending','Converted']
const PLANS = ['Basic Health Plan','Enhanced Plan','Premium Plan','Family Plan','Corporate Group']
const CONTACTS = ['Phone','In Person','Virtual/Video','Email','WhatsApp']

const blank = { date: new Date().toISOString().slice(0,10), activity_type:'', client_name:'', contact_mode:'Phone', outcome:'', plan:'', premium:'', follow_up_date:'', notes:'' }

export default function LogActivity() {
  const { session } = useAuth()
  const [form, setForm] = useState(blank)
  const [saving, setSaving] = useState(false)
  const [toast, setToast] = useState(null)
  const [recent, setRecent] = useState([])
  const [kpi, setKpi] = useState(null)
  const now = new Date(); const month = now.toLocaleString('default',{month:'long'}); const year = now.getFullYear()

  useEffect(() => {
    async function load() {
      const [{ data: ac }, { data: kp }] = await Promise.all([
        supabase.from('activities').select('*').eq('agent_id', session.agentId).order('date',{ascending:false}).limit(5),
        supabase.from('kpi_targets').select('*').eq('agent_id', session.agentId).eq('month', month).eq('year', year).single()
      ])
      setRecent(ac||[]); setKpi(kp)
    }
    load()
  }, [])

  const f = (k,v) => setForm(p=>({...p,[k]:v}))

  const submit = async () => {
    if (!form.activity_type || !form.client_name || !form.outcome) {
      alert('Please fill in Activity Type, Client Name, and Outcome'); return
    }
    setSaving(true)
    const { error } = await supabase.from('activities').insert([{
      ...form, agent_id: session.agentId, agent_name: session.name,
      premium: parseFloat(form.premium)||0
    }])
    if (!error) {
      setToast('Activity logged successfully!'); setTimeout(()=>setToast(null),2500)
      setForm(blank)
      const { data: ac } = await supabase.from('activities').select('*').eq('agent_id',session.agentId).order('date',{ascending:false}).limit(5)
      setRecent(ac||[])
    }
    setSaving(false)
  }

  const policiesSold = recent.filter(a=>a.outcome==='Successful'||a.outcome==='Converted').length
  const premiumTotal = recent.reduce((s,a)=>s+(a.premium||0),0)

  return (
    <PageShell title="Log Activity" subtitle={`${session.name} · ${session.zone}`}>
      {toast && <Toast msg={toast}/>}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Form */}
        <div className="lg:col-span-2 card p-6">
          <div className="font-display font-bold text-slate-700 mb-4">New Activity Entry</div>
          <div className="grid grid-cols-2 gap-4">
            <FormGroup label="Date *">
              <input type="date" value={form.date} onChange={e=>f('date',e.target.value)} className="form-input"/>
            </FormGroup>
            <FormGroup label="Activity Type *">
              <select value={form.activity_type} onChange={e=>f('activity_type',e.target.value)} className="form-input">
                <option value="">-- Select --</option>
                {ACTIVITY_TYPES.map(t=><option key={t}>{t}</option>)}
              </select>
            </FormGroup>
            <FormGroup label="Client / Prospect Name *">
              <input type="text" value={form.client_name} onChange={e=>f('client_name',e.target.value)} placeholder="Full name or company" className="form-input"/>
            </FormGroup>
            <FormGroup label="Contact Mode">
              <select value={form.contact_mode} onChange={e=>f('contact_mode',e.target.value)} className="form-input">
                {CONTACTS.map(c=><option key={c}>{c}</option>)}
              </select>
            </FormGroup>
            <FormGroup label="Plan of Interest">
              <select value={form.plan} onChange={e=>f('plan',e.target.value)} className="form-input">
                <option value="">-- Select Plan --</option>
                {PLANS.map(p=><option key={p}>{p}</option>)}
              </select>
            </FormGroup>
            <FormGroup label="Premium Value (GHS)">
              <input type="number" value={form.premium} onChange={e=>f('premium',e.target.value)} placeholder="0.00" min="0" className="form-input"/>
            </FormGroup>
            <FormGroup label="Outcome *">
              <select value={form.outcome} onChange={e=>f('outcome',e.target.value)} className="form-input">
                <option value="">-- Select --</option>
                {OUTCOMES.map(o=><option key={o}>{o}</option>)}
              </select>
            </FormGroup>
            <FormGroup label="Follow-Up Date">
              <input type="date" value={form.follow_up_date} onChange={e=>f('follow_up_date',e.target.value)} className="form-input"/>
            </FormGroup>
          </div>
          <FormGroup label="Notes / Details">
            <textarea value={form.notes} onChange={e=>f('notes',e.target.value)} rows={3} placeholder="Brief description, outcome details, next steps..." className="form-input"/>
          </FormGroup>
          <button onClick={submit} disabled={saving} className="btn-success w-full justify-center mt-2 py-2.5 text-base">
            {saving ? 'Submitting...' : '✓ Submit Activity'}
          </button>
        </div>

        {/* Right panel */}
        <div className="space-y-4">
          <div className="grid grid-cols-2 lg:grid-cols-1 gap-3">
            <StatCard label="Recent Policies" value={policiesSold} color="text-[#1E8449]" sub="successful"/>
            <StatCard label="Recent Premium" value={`GHS ${premiumTotal.toLocaleString()}`} color="text-amber-700"/>
            {kpi && <StatCard label="Monthly Target" value={`${kpi.new_clients_actual||0}/${kpi.new_clients_target}`} color="text-[#1A5276]" sub="new clients"/>}
          </div>

          <div className="card overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-100 font-display font-bold text-slate-700 text-sm">Recent Entries</div>
            {recent.length === 0
              ? <div className="p-4 text-sm text-slate-400 text-center">No activities yet</div>
              : <div className="divide-y divide-slate-50">
                  {recent.map(a=>(
                    <div key={a.id} className="px-4 py-3">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="text-xs font-medium text-slate-700">{a.activity_type}</div>
                          <div className="text-xs text-slate-400">{a.client_name}</div>
                          {a.premium>0 && <div className="text-xs text-[#1E8449] font-medium">GHS {a.premium.toLocaleString()}</div>}
                        </div>
                        <div className="text-right flex-shrink-0">
                          <OutcomeBadge outcome={a.outcome}/>
                          <div className="text-[10px] text-slate-400 mt-0.5">{a.date}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>}
          </div>
        </div>
      </div>
    </PageShell>
  )
}
