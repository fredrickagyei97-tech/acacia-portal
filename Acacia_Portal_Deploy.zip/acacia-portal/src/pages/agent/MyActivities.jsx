import { useState, useEffect } from 'react'
import { useAuth } from '../../lib/auth.jsx'
import { supabase } from '../../lib/supabase.js'
import { PageShell, OutcomeBadge, ProgressBar, ScoreBadge } from '../../components/shared.jsx'

export function MyActivities() {
  const { session } = useAuth()
  const [activities, setActivities] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('')

  useEffect(() => {
    supabase.from('activities').select('*').eq('agent_id', session.agentId).order('date',{ascending:false}).then(({data})=>{
      setActivities(data||[]); setLoading(false)
    })
  }, [])

  const filtered = filter ? activities.filter(a=>a.activity_type===filter||a.outcome===filter) : activities
  const types = [...new Set(activities.map(a=>a.activity_type))]

  if (loading) return <main className="ml-52 mt-14 p-6"><div className="text-slate-400 animate-pulse">Loading...</div></main>

  return (
    <PageShell title="My Activities" subtitle={`${activities.length} total entries`}>
      <div className="mb-4 flex gap-3 flex-wrap">
        <select value={filter} onChange={e=>setFilter(e.target.value)} className="form-input w-auto">
          <option value="">All Types</option>
          {types.map(t=><option key={t}>{t}</option>)}
        </select>
        {filter && <button onClick={()=>setFilter('')} className="btn-secondary text-xs">Clear</button>}
      </div>
      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-100">
              {['Date','Activity Type','Client','Contact','Plan','Premium','Outcome','Follow-Up','Notes'].map(h=>(
                <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-slate-400 uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.length===0
              ? <tr><td colSpan={9} className="px-4 py-10 text-center text-slate-400">No activities found</td></tr>
              : filtered.map(a=>(
                <tr key={a.id} className="table-row">
                  <td className="px-4 py-3 text-xs text-slate-500 whitespace-nowrap">{a.date}</td>
                  <td className="px-4 py-3 font-medium text-slate-700">{a.activity_type}</td>
                  <td className="px-4 py-3 text-slate-600">{a.client_name}</td>
                  <td className="px-4 py-3 text-xs text-slate-500">{a.contact_mode}</td>
                  <td className="px-4 py-3 text-xs text-slate-500">{a.plan||'—'}</td>
                  <td className="px-4 py-3 text-xs text-[#1E8449] font-medium">{a.premium>0?`GHS ${a.premium.toLocaleString()}`:'—'}</td>
                  <td className="px-4 py-3"><OutcomeBadge outcome={a.outcome}/></td>
                  <td className="px-4 py-3 text-xs text-blue-600">{a.follow_up_date||'—'}</td>
                  <td className="px-4 py-3 text-xs text-slate-400 max-w-xs truncate">{a.notes||'—'}</td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </PageShell>
  )
}

export function MyKPIs() {
  const { session } = useAuth()
  const [kpi, setKpi] = useState(null)
  const [loading, setLoading] = useState(true)
  const now = new Date(); const month = now.toLocaleString('default',{month:'long'}); const year = now.getFullYear()

  useEffect(() => {
    supabase.from('kpi_targets').select('*').eq('agent_id',session.agentId).eq('month',month).eq('year',year).single().then(({data})=>{
      setKpi(data); setLoading(false)
    })
  }, [])

  const calcScore = (k) => {
    if (!k) return 0
    const np = k.new_clients_target>0?(k.new_clients_actual||0)/k.new_clients_target:0
    const rp = k.renewals_target>0?(k.renewals_actual||0)/k.renewals_target:0
    const pp = k.premium_target>0?(k.premium_actual||0)/k.premium_target:0
    return Math.round((np*0.4+rp*0.3+pp*0.3)*100)
  }

  if (loading) return <main className="ml-52 mt-14 p-6"><div className="text-slate-400 animate-pulse">Loading...</div></main>

  const sc = calcScore(kpi)

  return (
    <PageShell title="My KPIs" subtitle={`${month} ${year} — Your performance`}>
      {!kpi ? (
        <div className="card p-8 text-center text-slate-400">No KPI targets set for this month yet. Contact your Unit Head.</div>
      ) : (
        <div className="max-w-lg space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="card p-5 text-center">
              <div className="text-3xl font-display font-bold mb-1" style={{color:sc>=75?'#1E8449':sc>=60?'#854F0B':'#E74C3C'}}>{sc}%</div>
              <div className="text-xs text-slate-400 mb-2">Overall Score</div>
              <ScoreBadge score={sc}/>
            </div>
            <div className="card p-5 text-center">
              <div className="text-3xl font-display font-bold text-[#1A5276] mb-1">{sc>=75?'✓':'!'}</div>
              <div className="text-xs text-slate-400 mb-2">Incentive Eligible</div>
              <span className={`badge ${sc>=75?'badge-green':'badge-amber'}`}>{sc>=75?'YES — ≥ 75%':'NOT YET'}</span>
            </div>
          </div>
          <div className="card p-5 space-y-4">
            {[
              {label:'New Clients',actual:kpi.new_clients_actual||0,target:kpi.new_clients_target,unit:''},
              {label:'Renewals',actual:kpi.renewals_actual||0,target:kpi.renewals_target,unit:''},
              {label:'Premium Collected (GHS)',actual:kpi.premium_actual||0,target:kpi.premium_target,unit:'GHS ',fmt:true}
            ].map(k=>(
              <div key={k.label}>
                <div className="flex justify-between text-sm mb-2">
                  <span className="font-medium text-slate-700">{k.label}</span>
                  <span className="text-slate-500">{k.fmt?k.actual.toLocaleString():k.actual} / {k.fmt?k.target.toLocaleString():k.target}</span>
                </div>
                <ProgressBar value={k.actual} max={k.target}/>
              </div>
            ))}
          </div>
          <div className="card p-4 text-xs text-slate-400">
            <div className="font-medium text-slate-600 mb-1">Rating Guide</div>
            STAR ≥ 90% · HIGH ≥ 75% · MID ≥ 60% · LOW &lt; 60%<br/>
            Scoring: New Clients 40% + Renewals 30% + Premium 30%
          </div>
        </div>
      )}
    </PageShell>
  )
}

export function MyProfile() {
  const { session } = useAuth()
  const [agent, setAgent] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    supabase.from('agents').select('*').eq('id',session.agentId).single().then(({data})=>{
      setAgent(data); setLoading(false)
    })
  }, [])

  if (loading) return <main className="ml-52 mt-14 p-6"><div className="text-slate-400 animate-pulse">Loading...</div></main>
  if (!agent) return null

  return (
    <PageShell title="My Profile" subtitle="Your details on record">
      <div className="max-w-md card p-6">
        <div className="flex items-center gap-4 mb-5 pb-5 border-b border-slate-100">
          <div className="w-14 h-14 rounded-full bg-[#1A5276]/10 flex items-center justify-center font-display font-bold text-[#1A5276] text-xl">
            {agent.name.split(' ').map(w=>w[0]).join('').slice(0,2)}
          </div>
          <div>
            <div className="font-display font-bold text-slate-800 text-lg">{agent.name}</div>
            <div className="text-sm text-slate-500">{agent.id} · Health Planner</div>
            <span className={`badge mt-1 ${agent.status==='Active'?'badge-green':'badge-amber'}`}>{agent.status}</span>
          </div>
        </div>
        <div className="space-y-3 text-sm">
          {[
            ['Zone / Territory', agent.zone],
            ['Contract Type', agent.contract_type],
            ['Phone', agent.phone],
            ['Email', agent.email],
            ['Date Joined', agent.joined],
            ['NIC License No.', agent.license_no],
            ['License Expiry', agent.license_expiry],
          ].map(([k,v])=>(
            <div key={k} className="flex justify-between items-center py-1 border-b border-slate-50">
              <span className="text-slate-400 text-xs">{k}</span>
              <span className="text-slate-700 font-medium text-xs">{v}</span>
            </div>
          ))}
        </div>
      </div>
    </PageShell>
  )
}

export default MyActivities
