export { MyProfile as default } from './MyActivities.jsx'
