import { Routes, Route, Navigate } from 'react-router-dom'
import { TopNav, Sidebar } from '../components/shared.jsx'
import Dashboard from './head/Dashboard.jsx'
import AgentRoster from './head/AgentRoster.jsx'
import AgentDetail from './head/AgentDetail.jsx'
import KPITracker from './head/KPITracker.jsx'
import AllActivities from './head/AllActivities.jsx'
import CoachingLog from './head/CoachingLog.jsx'

const links = [
  { label: 'Overview', items: [
    { path: '', icon: '📊', label: 'Dashboard' },
  ]},
  { label: 'Agents', items: [
    { path: 'agents', icon: '👥', label: 'Agent Roster' },
    { path: 'kpi', icon: '🎯', label: 'KPI Tracker' },
  ]},
  { label: 'Records', items: [
    { path: 'activities', icon: '📋', label: 'All Activities' },
    { path: 'coaching', icon: '💬', label: 'Coaching Log' },
  ]}
]

export default function UnitHeadLayout() {
  return (
    <>
      <TopNav />
      <Sidebar links={links} basePath="/dashboard" />
      <Routes>
        <Route index element={<Dashboard />} />
        <Route path="agents" element={<AgentRoster />} />
        <Route path="agents/:id" element={<AgentDetail />} />
        <Route path="kpi" element={<KPITracker />} />
        <Route path="activities" element={<AllActivities />} />
        <Route path="coaching" element={<CoachingLog />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </>
  )
}
