import { Routes, Route, Navigate } from 'react-router-dom'
import { TopNav, Sidebar } from '../components/shared.jsx'
import LogActivity from './agent/LogActivity.jsx'
import MyActivities from './agent/MyActivities.jsx'
import MyProfile from './agent/MyProfile.jsx'
import MyKPIs from './agent/MyKPIs.jsx'

const links = [
  { label: '', items: [
    { path: '', icon: '➕', label: 'Log Activity' },
    { path: 'activities', icon: '📋', label: 'My Activities' },
    { path: 'kpis', icon: '🎯', label: 'My KPIs' },
    { path: 'profile', icon: '👤', label: 'My Profile' },
  ]}
]

export default function AgentLayout() {
  return (
    <>
      <TopNav />
      <Sidebar links={links} basePath="/agent" />
      <Routes>
        <Route index element={<LogActivity />} />
        <Route path="activities" element={<MyActivities />} />
        <Route path="kpis" element={<MyKPIs />} />
        <Route path="profile" element={<MyProfile />} />
        <Route path="*" element={<Navigate to="/agent" replace />} />
      </Routes>
    </>
  )
}
