import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './lib/auth.jsx'
import LoginPage from './pages/LoginPage.jsx'
import UnitHeadLayout from './pages/UnitHeadLayout.jsx'
import AgentLayout from './pages/AgentLayout.jsx'

function ProtectedHead({ children }) {
  const { session } = useAuth()
  if (!session || session.role !== 'head') return <Navigate to="/" replace />
  return children
}

function ProtectedAgent({ children }) {
  const { session } = useAuth()
  if (!session || session.role !== 'agent') return <Navigate to="/" replace />
  return children
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<LoginPage />} />
      <Route path="/dashboard/*" element={<ProtectedHead><UnitHeadLayout /></ProtectedHead>} />
      <Route path="/agent/*" element={<ProtectedAgent><AgentLayout /></ProtectedAgent>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
