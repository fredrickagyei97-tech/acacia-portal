import { useAuth } from '../lib/auth.jsx'
import { useNavigate, useLocation } from 'react-router-dom'

export function TopNav({ links }) {
  const { session, logout } = useAuth()
  const navigate = useNavigate()
  const doLogout = () => { logout(); navigate('/') }

  return (
    <header className="fixed top-0 left-0 right-0 h-14 bg-[#1A5276] z-40 flex items-center justify-between px-4 shadow-md">
      <div className="flex items-center gap-3">
        <span className="text-xl">🏥</span>
        <div>
          <div className="text-white font-display font-bold text-sm leading-tight">Acacia Health Insurance</div>
          <div className="text-white/50 text-[10px] leading-tight">Retail Unit · Agent Portal</div>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <span className="text-white/70 text-xs hidden sm:block">{session?.name}</span>
        <button onClick={doLogout} className="text-xs text-white/70 hover:text-white border border-white/20 hover:border-white/40 px-3 py-1.5 rounded-lg transition-all">
          Sign Out
        </button>
      </div>
    </header>
  )
}

export function Sidebar({ links, basePath }) {
  const location = useLocation()
  const navigate = useNavigate()
  return (
    <aside className="fixed left-0 top-14 bottom-0 w-52 bg-white border-r border-slate-100 z-30 overflow-y-auto py-4">
      {links.map(section => (
        <div key={section.label} className="mb-2">
          {section.label && <div className="px-4 py-1.5 text-[10px] font-semibold text-slate-400 uppercase tracking-widest">{section.label}</div>}
          {section.items.map(item => {
            const active = location.pathname === `${basePath}/${item.path}` || (item.path==='' && location.pathname===basePath)
            return (
              <div key={item.path} onClick={()=>navigate(`${basePath}/${item.path}`)}
                className={`nav-item mx-2 ${active?'active':''}`}>
                <span className="text-base">{item.icon}</span>
                <span>{item.label}</span>
              </div>
            )
          })}
        </div>
      ))}
    </aside>
  )
}

export function PageShell({ title, subtitle, action, children }) {
  return (
    <main className="ml-52 mt-14 min-h-[calc(100vh-56px)] bg-slate-50 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-start justify-between mb-5">
          <div>
            <h1 className="font-display text-xl font-bold text-slate-800">{title}</h1>
            {subtitle && <p className="text-sm text-slate-500 mt-0.5">{subtitle}</p>}
          </div>
          {action}
        </div>
        {children}
      </div>
    </main>
  )
}

export function StatCard({ label, value, color = 'text-[#1A5276]', sub }) {
  return (
    <div className="stat-card">
      <div className="text-xs font-medium text-slate-400 uppercase tracking-wide mb-1">{label}</div>
      <div className={`text-2xl font-display font-bold ${color}`}>{value}</div>
      {sub && <div className="text-xs text-slate-400 mt-0.5">{sub}</div>}
    </div>
  )
}

export function Avatar({ name, id, size = 'md' }) {
  const colors = [['#E6F1FB','#185FA5'],['#D5F5E3','#1E8449'],['#FAEEDA','#854F0B'],['#FBEAF0','#993556'],['#EEEDFE','#3C3489'],['#E1F5EE','#085041']]
  const [bg, fg] = colors[(parseInt(id?.split('-')[1]||'1')-1) % colors.length]
  const initials = name?.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase()
  const sz = size === 'lg' ? 'w-12 h-12 text-base' : size === 'sm' ? 'w-7 h-7 text-xs' : 'w-9 h-9 text-sm'
  return (
    <div className={`${sz} rounded-full flex items-center justify-center font-semibold flex-shrink-0`} style={{background:bg,color:fg}}>
      {initials}
    </div>
  )
}

export function ScoreBadge({ score }) {
  const band = score >= 90 ? ['STAR','badge-green'] : score >= 75 ? ['HIGH','badge-blue'] : score >= 60 ? ['MID','badge-amber'] : ['LOW','badge-red']
  return <span className={`badge ${band[1]}`}>{band[0]}</span>
}

export function StatusBadge({ status }) {
  const map = { Active: 'badge-green', 'On Leave': 'badge-amber', Inactive: 'badge-red' }
  return <span className={`badge ${map[status]||'badge-gray'}`}>{status}</span>
}

export function OutcomeBadge({ outcome }) {
  const map = { Successful: 'badge-green', Converted: 'badge-green', Pending: 'badge-amber', 'Follow-Up Needed': 'badge-amber', 'Not Interested': 'badge-red', Closed: 'badge-blue' }
  return <span className={`badge ${map[outcome]||'badge-gray'}`}>{outcome}</span>
}

export function ProgressBar({ value, max, color }) {
  const pct = Math.min(Math.round((value / max) * 100), 100)
  const c = pct >= 90 ? '#1E8449' : pct >= 75 ? '#185FA5' : pct >= 60 ? '#854F0B' : '#E74C3C'
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all duration-500" style={{width:`${pct}%`,background:color||c}}/>
      </div>
      <span className="text-xs font-medium w-10 text-right" style={{color:color||c}}>{pct}%</span>
    </div>
  )
}

export function Modal({ title, onClose, children }) {
  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={e=>e.stopPropagation()}>
        <div className="flex items-center justify-between p-5 border-b border-slate-100">
          <h2 className="font-display font-bold text-slate-800">{title}</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 text-xl leading-none w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-100">×</button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  )
}

export function FormGroup({ label, children }) {
  return (
    <div className="mb-4">
      <label className="block text-xs font-medium text-slate-500 mb-1.5">{label}</label>
      {children}
    </div>
  )
}

export function Toast({ msg, type = 'success' }) {
  return (
    <div className={`fixed bottom-6 right-6 z-50 px-4 py-3 rounded-xl shadow-lg text-sm font-medium text-white ${type==='success'?'bg-[#1E8449]':'bg-red-600'}`}>
      {type === 'success' ? '✓ ' : '✗ '}{msg}
    </div>
  )
}
